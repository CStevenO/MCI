#include <ESP8266WiFi.h>
#include <PubSubClient.h>
const char* ssid = "MTOinvernadero";                           //!!!!!!!!!!!!!!!!!!!!!
const char* password = "MTOinv2017";                //!!!!!!!!!!!!!!!!!!!!!
const char* mqtt_server = "192.168.1.179";                 //!!!!!!!!!!!!!!!!!!!!!
WiFiClient espClient;
PubSubClient client(espClient);
String mensaje = "";
String mMQTT = "";
