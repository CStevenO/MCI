//Serial.begin(9600);
//LCD
lcd.init();
lcd.backlight();
lcd.clear();
//RTC
RTC.begin();
//
//RTC.adjust(DateTime(__DATE__, __TIME__)); //Ajustar Hora
gsm.begin(9600);
sht31.begin(0x44);
// esp.begin(9600);
watchdogSetup();
