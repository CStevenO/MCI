//Serial.begin(9600);
//LCD
lcd.init();
lcd.backlight();
lcd.clear();
//RTC
RTC.begin();
//RTC.adjust(DateTime(__DATE__, __TIME__)); //Ajustar Hora
//COMUNICACION UART
esp.begin(9600);
//Perro
watchdogSetup();
