// LCD
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x3F, 16, 2);
#define imprimir(cadena){lcd.print(cadena);}
//SHT
unsigned long milisAnterior = 0;
#include <Arduino.h>
#include <Wire.h>
#include "Adafruit_SHT31.h"
Adafruit_SHT31 sht31 = Adafruit_SHT31();
float t;
float h;
#define OffsetT 0
#define OffsetH 0
// RTC
#include "RTClib.h"
#include <SPI.h>
#include <SD.h>
File myFile;
bool dato = false;                
String mensajeS = " ";
int lineas = 0;
int lineasc = 0;
char c;
String mensaje = "";
//#define intervalo 1000
boolean espera = true;
boolean envio = false;
bool m = false;
int idInv = 0;
bool eliminacion = false;
RTC_DS3231 RTC;
short anio = 0;
byte mes = 0;
byte dia = 0;
byte hora = 0;
byte minuto =  0;
byte segundo = 0;
#include <AltSoftSerial.h>
AltSoftSerial esp;
//MESH
#define intervalo 5
String mensajeSalida = "";
String mensajeEntrada = "";
byte idMensaje = 0;
byte indice = 0;
bool unicaVez = false;
int datos[6];
int idInvernadero=1826;
#define separador ','
byte i = 0;
////Perro
//#include <avr/wdt.h>
//unsigned long resetTime = 0;
//#define TIMEOUTPERIOD 20000  // You can make this time as long as you want, it's not limited to 8 seconds like the normal watchdog
//#define doggieTickle() resetTime = millis();  // This macro will reset the timer

