# psicrometro
Psicrometer arduino sketch 
With two 1-wire waterproof temperature sensors and a ZUM arduino (from bq)  you can make a high precission psicrometer.
It's output is a bluetooth signal and a 1 to 5 v output<br>
You can use it, for know or for control
